// @file:Suppress("unused")

package com.shoppi.app.common


var BFLAG = false


var GLOBALUID: String? = null
var SAFEUID = "0"