package com.shoppi.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.shoppi.app.R

class DevByteActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dev_byte_viewer)
    }
}

/*
* Note
* This is Test Activity
* Should be ignored
* */