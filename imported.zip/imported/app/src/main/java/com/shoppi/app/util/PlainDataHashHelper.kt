package com.shoppi.app.util

@Suppress("unused")
class PlainDataHashHelper {
}

/*
app 개발 95%이상 끝났을 때 비밀번호 해쉬 암호화 저장 적용하기
지금 적용하면 디버깅 작업이 힘들어짐
다 끝나고 마지막에 해도 전혀 문제 없는 작업
 */