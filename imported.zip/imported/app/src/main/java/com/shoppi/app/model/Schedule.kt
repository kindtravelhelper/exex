package com.shoppi.app.model


data class Schedule(
    val namelabel: String,
    val timerange: String
)
