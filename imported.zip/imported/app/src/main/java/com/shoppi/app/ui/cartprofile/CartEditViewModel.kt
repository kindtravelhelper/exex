package com.shoppi.app.ui.cartprofile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.shoppi.app.model.Cart

class CartEditViewModel(

) : ViewModel() {


    init {

    }
}

