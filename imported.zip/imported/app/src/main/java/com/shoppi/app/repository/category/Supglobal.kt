package com.shoppi.app.repository.category

object Supglobal {
    var mSup: String = ""
    var mLabel: String = ""
    var mLocation: String = ""
    var mPeriod: String = ""
    var mMemo: String = ""
}


// mSup is for thumbnail_image_url
// mLabel is for profile name