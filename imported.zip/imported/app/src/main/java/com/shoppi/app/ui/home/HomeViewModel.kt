package com.shoppi.app.ui.home

import androidx.lifecycle.ViewModel

@Suppress("unused")
class HomeViewModel/*(private val homeRepository: HomeRepository)*/ : ViewModel() {


//    init {
//        loadHomeData()
//    }
//
//    private fun loadHomeData() {
//
//    }
}