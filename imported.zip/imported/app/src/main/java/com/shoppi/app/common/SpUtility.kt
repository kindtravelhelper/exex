@file:Suppress("unused")

package com.shoppi.app.common

import android.content.Context

class SpUtility(private val context: Context) {
    /*

    fun myInitSup() {
        val preferences: SharedPreferences? =
            context.getSharedPreferences("imagesNumByUserPicked", Context.MODE_PRIVATE)
        val iNumPicked: Int? = preferences?.getInt("imagesNumByUserPicked", 0)

    }

    fun myInitSup2() {
        val preferences: SharedPreferences? =
            context.getSharedPreferences("myMutables", Context.MODE_PRIVATE)
        val resultI = preferences?.getStringSet(
            "myMutables", setOf(
                "https://webkit.org/blog-files/color-gamut/YellowFlower-sRGB.jpg"
            )
        )

    }

    */
}