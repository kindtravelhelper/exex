package com.shoppi.app.ui.common

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.shoppi.app.R

class MoveToGalleryCameraPickOneWithNextActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_move_to_gallery_camera_pick_one_with_next)
    }
}