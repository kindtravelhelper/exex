@file:Suppress("unused")

package com.shoppi.app.repository.category

object Supnum {
}

// future use shared pref with global object Supnum Lasting Activity